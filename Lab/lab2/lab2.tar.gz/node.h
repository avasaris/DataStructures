// CS14
// This file contains the node class declaration.

#ifndef __NODE_H_
#define __NODE_H_

class Node {
public:
  Node* next;
  int value;
};

#endif
